export default interface ILang {
    lang: 'en' | 'fa';
  }