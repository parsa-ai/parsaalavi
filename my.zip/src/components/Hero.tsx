import React from 'react';
import { ChevronRight } from 'lucide-react';
import  ILang  from "./ILang";

const Hero: React.FC<ILang> = ({ lang }) => {
  const content = {
    en: {
      greeting: "Hello, I'm",
      name: "Parsa Alavi",
      title: "Creative Front-end Developer",
      viewWork: "View My Work",
      contact: "Contact Me"
    },
    fa: {
      greeting: "سلام، من",
      name: "پارسا علوی",
      title: "توسعه‌دهنده خلاق فرانت‌اند",
      viewWork: "نمونه کارها",
      contact: "تماس با من"
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center py-20">
      <div className="text-center animate-fade-in">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          <span className="text-slate-400">{content[lang].greeting}</span>
          <br />
          <span className="bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent hover-lift">
            {content[lang].name}
          </span>
        </h1>
        <p className="text-xl md:text-2xl text-slate-400 mb-8 animate-slide-in" style={{ animationDelay: '0.2s' }}>
          {content[lang].title}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-scale-in" style={{ animationDelay: '0.4s' }}>
          <a
            href="#portfolio"
            className="button-hover inline-flex items-center gap-2 bg-white text-slate-900 px-6 py-3 rounded-full font-medium hover:bg-slate-200 transition-colors"
          >
            {content[lang].viewWork}
            <ChevronRight size={20} className={lang === 'fa' ? 'rotate-180' : ''} />
          </a>
          <a
            href="#contact"
            className="button-hover inline-flex items-center gap-2 bg-slate-800 text-white px-6 py-3 rounded-full font-medium hover:bg-slate-700 transition-colors"
          >
            {content[lang].contact}
            <ChevronRight size={20} className={lang === 'fa' ? 'rotate-180' : ''} />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;