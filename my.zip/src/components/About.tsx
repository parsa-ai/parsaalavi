import React from 'react';
import ILang from './ILang';

const About: React.FC<ILang> = ({ lang }) => {
  const content = {
    en: {
      title: 'About Me',
      description1: `Hi! I'm Parsa, an 18-year-old front-end developer with 3 years of experience in creating beautiful and functional web experiences. Currently studying Computer Engineering at Chamran University, I combine my academic knowledge with practical expertise in Angular, React, Next.js, and WordPress.`,
      description2: `I'm passionate about learning new technologies and sharing knowledge with others. My experience includes working on various projects, from small business websites to complex web applications. I believe in the power of teamwork and continuous improvement.`,
      age: 'Age:',
      education: 'Education:',
      university: 'University:',
      experience: 'Experience:',
      values: {
        age: '18',
        education: 'Computer Engineering',
        university: 'Chamran University',
        experience: '3 Years'
      },
      // profileText: 'Parsa Alavi'
    },
    fa: {
      title: 'درباره من',
      description1: `سلام! من پارسا هستم، یک توسعه‌دهنده فرانت‌اند ۱۸ ساله با ۳ سال تجربه در ایجاد تجربیات وب زیبا و کاربردی. در حال حاضر در دانشگاه چمران مهندسی کامپیوتر می‌خوانم و دانش آکادمیک خود را با تخصص عملی در انگولار، ری‌اکت، نکست.جی‌اس و وردپرس ترکیب می‌کنم.`,
      description2: `من به یادگیری فناوری‌های جدید و اشتراک‌گذاری دانش با دیگران علاقه‌مندم. تجربه من شامل کار بر روی پروژه‌های مختلف، از وب‌سایت‌های کسب‌وکار کوچک تا برنامه‌های وب پیچیده است. من به قدرت کار تیمی و بهبود مستمر اعتقاد دارم.`,
      age: 'سن:',
      education: 'تحصیلات:',
      university: 'دانشگاه:',
      experience: 'تجربه:',
      values: {
        age: '۱۸',
        education: 'مهندسی کامپیوتر',
        university: 'دانشگاه چمران',
        experience: '۳ سال'
      },
      // profileText: 'پارسا علوی'
    }
  };

  const NewLang = content[lang] || content.en;

  return (
    <section id="about" className="py-20">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold mb-8">{NewLang.title}</h2>
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="relative group">
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800"
              alt="Parsa Alavi"
              className="rounded-2xl w-full object-cover aspect-square"
            />
            <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl flex items-center justify-center">
              {/* <p className="text-sm text-center px-4">{NewLang.profileText}</p> */}
            </div>
          </div>
          <div className="space-y-4">
            <p className="text-slate-400">{NewLang.description1}</p>
            <p className="text-slate-400">{NewLang.description2}</p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-slate-400">{NewLang.age}</p>
                <p className="font-medium">{NewLang.values.age}</p>
              </div>
              <div>
                <p className="text-slate-400">{NewLang.education}</p>
                <p className="font-medium">{NewLang.values.education}</p>
              </div>
              <div>
                <p className="text-slate-400">{NewLang.university}</p>
                <p className="font-medium">{NewLang.values.university}</p>
              </div>
              <div>
                <p className="text-slate-400">{NewLang.experience}</p>
                <p className="font-medium">{NewLang.values.experience}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
