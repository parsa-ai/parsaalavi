import React from 'react';
import ILang from './ILang';

const Experience: React.FC<ILang> = ({ lang }) => {
  const content = {
    en: {
      title: "Experience",
      experiences: [
        {
          period: '2023 - Present',
          title: 'Senior Front-end Developer',
          company: 'Tech Solutions Inc.',
          description: 'Leading front-end development team, implementing modern web solutions using Angular and React.'
        },
        {
          period: '2022 - 2023',
          title: 'WordPress Developer',
          company: 'Creative Agency',
          description: 'Developed custom WordPress themes and plugins for various clients.'
        },
        {
          period: '2021 - 2022',
          title: 'Junior Developer',
          company: 'Web Studio',
          description: 'Started career as a junior developer working on various web projects.'
        }
      ]
    },
    fa: {
      title: "تجربیات",
      experiences: [
        {
          period: '۲۰۲۳ - اکنون',
          title: 'توسعه‌دهنده ارشد فرانت‌اند',
          company: 'Tech Solutions Inc.',
          description: 'رهبری تیم توسعه فرانت‌اند و پیاده‌سازی راه‌حل‌های مدرن وب با استفاده از Angular و React.'
        },
        {
          period: '۲۰۲۲ - ۲۰۲۳',
          title: 'توسعه‌دهنده وردپرس',
          company: 'Creative Agency',
          description: 'توسعه تم‌ها و افزونه‌های سفارشی وردپرس برای مشتریان مختلف.'
        },
        {
          period: '۲۰۲۱ - ۲۰۲۲',
          title: 'توسعه‌دهنده جونیور',
          company: 'Web Studio',
          description: 'شروع حرفه به عنوان توسعه‌دهنده جونیور و کار بر روی پروژه‌های مختلف وب.'
        }
      ]
    }
  };

  return (
    <section id="experience" className={`py-20 ${lang === 'fa' ? 'rtl' : 'ltr'}`}>
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold mb-8">{content[lang].title}</h2>
        
        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-0 top-0 bottom-0 w-px bg-slate-800"></div>

          {/* Experience Items */}
          <div className="space-y-12">
            {content[lang].experiences.map((exp, index) => (
              <div key={index} className="relative pl-8">
                {/* Timeline Dot */}
                <div className="absolute left-0 top-0 w-2 h-2 bg-white rounded-full -translate-x-1/2"></div>

                {/* Content */}
                <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl">
                  <span className="inline-block bg-slate-700 text-sm px-3 py-1 rounded-full mb-4">
                    {exp.period}
                  </span>
                  <h3 className="text-xl font-semibold mb-2">{exp.title}</h3>
                  <p className="text-slate-400 mb-2">{exp.company}</p>
                  <p className="text-slate-300">{exp.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
