import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react';
import ILang from "./ILang";

const Portfolio: React.FC<ILang> = ({ lang }) => {
  const content = {
    en: {
      title: 'Portfolio',
      viewProject: 'View Project',
      projects: [
        {
          title: 'E-commerce Platform',
          description: 'A modern e-commerce platform built with Next.js and Tailwind CSS',
          image: 'https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&q=80&w=800',
          technologies: ['Next.js', 'TypeScript', 'Tailwind CSS'],
          link: '#'
        },
        {
          title: 'Blog Platform',
          description: 'Custom WordPress theme with modern design and features',
          image: 'https://images.unsplash.com/photo-1432888622747-4eb9a8f2c1d9?auto=format&fit=crop&q=80&w=800',
          technologies: ['WordPress', 'PHP', 'JavaScript'],
          link: '#'
        },
        {
          title: 'Task Management App',
          description: 'Angular-based task management application with real-time updates',
          image: 'https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?auto=format&fit=crop&q=80&w=800',
          technologies: ['Angular', 'TypeScript', 'Firebase'],
          link: '#'
        }
      ]
    },
    fa: {
      title: 'نمونه کارها',
      viewProject: 'مشاهده پروژه',
      projects: [
        {
          title: 'پلتفرم تجارت الکترونیک',
          description: 'یک پلتفرم مدرن تجارت الکترونیک با Next.js و Tailwind CSS',
          image: 'https://images.unsplash.com/photo-1557821552-17105176677c?auto=format&fit=crop&q=80&w=800',
          technologies: ['Next.js', 'TypeScript', 'Tailwind CSS'],
          link: '#'
        },
        {
          title: 'پلتفرم وبلاگ',
          description: 'قالب اختصاصی وردپرس با طراحی و ویژگی‌های مدرن',
          image: 'https://images.unsplash.com/photo-1432888622747-4eb9a8f2c1d9?auto=format&fit=crop&q=80&w=800',
          technologies: ['وردپرس', 'PHP', 'جاوااسکریپت'],
          link: '#'
        },
        {
          title: 'اپلیکیشن مدیریت وظایف',
          description: 'برنامه مدیریت وظایف مبتنی بر Angular با بروزرسانی‌های لحظه‌ای',
          image: 'https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?auto=format&fit=crop&q=80&w=800',
          technologies: ['Angular', 'TypeScript', 'Firebase'],
          link: '#'
        }
      ]
    }
  };

  const [currentIndex, setCurrentIndex] = useState(0);

  const nextProject = () => {
    setCurrentIndex((prev) => (prev + 1) % content[lang].projects.length);
  };

  const prevProject = () => {
    setCurrentIndex((prev) => (prev - 1 + content[lang].projects.length) % content[lang].projects.length);
  };

  return (
    <section id="portfolio" className="py-20">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold mb-8">{content[lang].title}</h2>

        <div className="relative">
          <div className="overflow-hidden rounded-2xl">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{
                transform: lang === 'fa'
                  ? `translateX(${currentIndex * 100}%)`  // تغییر جهت در نسخه فارسی
                  : `translateX(-${currentIndex * 100}%)`
              }}
            >
              {content[lang].projects.map((project, index) => (
                <div key={index} className="w-full flex-shrink-0">
                  <div className="relative group">
                    <img src={project.image} alt={project.title} className="w-full aspect-video object-cover" />
                    <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-center items-center p-8">
                      <h3 className="text-2xl font-bold mb-4">{project.title}</h3>
                      <p className="text-slate-300 text-center mb-4">{project.description}</p>
                      <div className="flex gap-2 mb-6">
                        {project.technologies.map((tech) => (
                          <span key={tech} className="bg-slate-700/50 px-3 py-1 rounded-full text-sm">
                            {tech}
                          </span>
                        ))}
                      </div>
                      <a href={project.link} className="inline-flex items-center gap-2 bg-white text-slate-900 px-6 py-2 rounded-full hover:bg-slate-200 transition-colors">
                        {content[lang].viewProject}
                        <ExternalLink size={16} />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={lang === 'fa' ? nextProject : prevProject}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white text-slate-900 p-2 rounded-full hover:bg-slate-200 transition-colors"
          >
            <ChevronLeft size={24} />
          </button>
          <button
            onClick={lang === 'fa' ? prevProject : nextProject}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white text-slate-900 p-2 rounded-full hover:bg-slate-200 transition-colors"
          >
            <ChevronRight size={24} />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
